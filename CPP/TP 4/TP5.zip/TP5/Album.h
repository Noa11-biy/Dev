#ifndef ALBUM_H
#define ALBUM_H

#include <string>
#include <vector>
#include <iostream>
#include "Image.h"

class Album {
private:
    std::string nom;
    std::vector<Image> images;

public:

    Album();
    Album(const std::string& nom);


    std::string getNom() const { return nom; }
    int getNbImages() const    { return images.size(); }
    const std::vector<Image>& getImages() const { return images; }


    void setNom(const std::string& n) { nom = n; }


    void ajouterImage(const Image& img);
    bool supprimerImage(const std::string& nomImage);


    std::vector<Image> rechercherParMotCle(const std::string& motCle) const;


    friend std::ostream& operator<<(std::ostream& os, const Album& a);
};

#endif