#include "Album.h"

Album::Album() : nom("Sans nom") {}

Album::Album(const std::string& nom) : nom(nom) {}

void Album::ajouterImage(const Image& img) {
    images.push_back(img);
}

bool Album::supprimerImage(const std::string& nomImage) {
    for (auto it = images.begin(); it != images.end(); ++it) {
        if (it->getNom() == nomImage) {
            images.erase(it);
            return true;
        }
    }
    return false;
}

std::vector<Image> Album::rechercherParMotCle(const std::string& motCle) const {
    std::vector<Image> resultats;
    for (const auto& img : images) {
        for (const auto& mc : img.getMotsCles()) {
            if (mc == motCle) {
                resultats.push_back(img);
                break;
            }
        }
    }
    return resultats;
}

std::ostream& operator<<(std::ostream& os, const Album& a) {
    os << "=== Album : " << a.nom << " ===\n";
    os << "Nombre d'images : " << a.images.size() << "\n";
    for (const auto& img : a.images) {
        os << "---\n" << img;
    }
    return os;
}