#include <iostream>
#include "Image.h"
#include "Album.h"

int main() {
    // Création de quelques images
    Image img1("vacances.pgm", Date(15, 7, 2023), 100, 100, 255);
    img1.addMotCle("plage");
    img1.addMotCle("vacances");

    Image img2("noel.pgm", Date(25, 12, 2024), 200, 200, 255);
    img2.addMotCle("noel");
    img2.addMotCle("famille");

    Image img3("plage2.pgm", Date(1, 8, 2023), 150, 150, 255);
    img3.addMotCle("plage");

    // Création de l'album
    Album mon_album("Mes souvenirs");
    mon_album.ajouterImage(img1);
    mon_album.ajouterImage(img2);
    mon_album.ajouterImage(img3);

    std::cout << mon_album << "\n";

    // Recherche
    std::cout << ">>> Recherche : 'plage'\n";
    auto resultats = mon_album.rechercherParMotCle("plage");
    std::cout << "Trouve " << resultats.size() << " image(s)\n";
    for (const auto& img : resultats) {
        std::cout << "  - " << img.getNom() << "\n";
    }

    // Suppression
    std::cout << "\n>>> Suppression de noel.pgm\n";
    mon_album.supprimerImage("noel.pgm");
    std::cout << "Nb restantes : " << mon_album.getNbImages() << "\n";

    return 0;
}